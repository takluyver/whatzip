use std::env;
use std::process;
use std::fs::File;
use std::io;
use std::io::prelude::*;

enum ArchiveType {
    Zip,
    Unknown
}

fn check_zip(f: &mut File) -> bool {
    if f.seek(io::SeekFrom::End(-46)).is_err() {
        return false;
    }
    let mut end_buf = Vec::new();
    if f.read_to_end(&mut end_buf).is_err() {
        return false;
    }
    if &end_buf[.. 4] != b"PK\x05\x06" {
        println!("boo");
        println!("Stuff {:?}", &end_buf[.. 4]);
        return false;
    } else {
        println!("Magic number matched");
    }
    println!("Slice {}", &end_buf[0 .. 4].len());
    return false;
}

fn detect_archive(f: &mut File) -> ArchiveType {
    if check_zip(f) {
        return ArchiveType::Zip;
    }
    return ArchiveType::Unknown
}

fn main() {
    match env::args().nth(1) {
        Some(s) => {
            match File::open(&s) {
                Ok(mut f) => {
                    println!("OK");
                    detect_archive(&mut f);
                },
                Err(_) => {
                    println!("Failed to open {}", s);
                    process::exit(1);
                }
            }
        },
        None => {
            println!("No argument!");
            process::exit(2);
        },
    }
}
